import os
from pathlib import Path


def _database_url(data_dir: Path) -> str:
    url = os.getenv("DATABASE_URL")
    if not url:
        return f"sqlite:///{data_dir / 'app.db'}"
    # Some PaaS providers expose postgres://; SQLAlchemy expects postgresql://
    if url.startswith("postgres://"):
        url = url.replace("postgres://", "postgresql://", 1)
    return url


class Config:
    BASE_DIR = Path(__file__).resolve().parent
    DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data")).resolve()
    UPLOAD_DIR = DATA_DIR / "uploads"
    REPORT_DIR = DATA_DIR / "reports"

    SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-change-me")
    SQLALCHEMY_DATABASE_URI = _database_url(DATA_DIR)
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "50"))
    MAX_CONTENT_LENGTH = MAX_UPLOAD_MB * 1024 * 1024
    ALLOWED_EXTENSIONS = {"csv", "xlsx", "xls"}

    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_HTTPONLY = True
