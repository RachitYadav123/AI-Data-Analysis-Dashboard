# Production AI Analytics Dashboard

A deploy-ready Python web app where users upload CSV/Excel datasets and get a Power BI-style interactive dashboard with automatic profiling, slicers, cross-filtering charts, dynamic KPIs, and optional AI-generated business summaries.

## What is production-ready in this version

- Flask authentication: register, login, logout
- User-scoped datasets: users only see their own uploads
- Persistent database via SQLite by default, PostgreSQL via `DATABASE_URL`
- Secure upload handling with filename sanitization, file type checks, and size limits
- CSV/XLSX/XLS support
- Auto column detection: numeric, categorical, date, text
- Auto dataset profile and data quality summary
- Dynamic KPI cards
- Power BI-style slicers and filters
- Click a bar or donut slice to cross-filter the entire dashboard
- Dynamic key insights
- Optional OpenAI-powered dataset summary through `OPENAI_API_KEY`
- Dockerfile, docker-compose, Render blueprint, Gunicorn production server, health check endpoint

## Quick local run without Docker

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py init-db
python manage.py
```

Open:

```text
http://127.0.0.1:10000
```

## Quick local run with Docker

```bash
cp .env.example .env
# Optional: edit .env and set SECRET_KEY properly.
docker compose up --build
```

Open:

```text
http://127.0.0.1:10000
```

## Direct Render deployment

1. Push this folder to GitHub.
2. In Render, create a new Blueprint or Web Service from the repo.
3. Render will use `render.yaml` and `Dockerfile`.
4. Add optional environment variable `OPENAI_API_KEY` if you want real AI summaries.
5. Deploy.

The app listens on the `PORT` environment variable and exposes `/healthz` for health checks.

## Environment variables

```env
SECRET_KEY=change-this-super-secret-key
DATABASE_URL=sqlite:////app/data/app.db
DATA_DIR=/app/data
MAX_UPLOAD_MB=50
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
PORT=10000
```

For PostgreSQL:

```env
DATABASE_URL=postgresql://user:password@host:5432/dbname
```

## How to use

1. Register a user.
2. Open `/dashboard/`.
3. Upload `sample_data/sample_sales_data.csv` or your own CSV/Excel.
4. Select metric, category, and date fields.
5. Use slicers or click visuals to filter the full dashboard.
6. Ask custom questions like:

```text
sales by region
top 10 products by profit
monthly revenue trend
missing values
correlation
```

## Notes for larger datasets

This app is suitable for small-to-medium datasets. For very large files, upgrade the engine to DuckDB/Polars, add background processing, and move uploads to object storage such as S3 or GCS.
