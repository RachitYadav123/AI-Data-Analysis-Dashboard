from flask import Blueprint, jsonify, render_template
from flask_login import current_user, login_required

from .models import Dataset

bp = Blueprint("main", __name__)


@bp.route("/")
def index():
    datasets = []
    if current_user.is_authenticated:
        datasets = Dataset.query.filter_by(user_id=current_user.id).order_by(Dataset.created_at.desc()).limit(5).all()
    return render_template("index.html", datasets=datasets)


@bp.route("/healthz")
def healthz():
    return jsonify({"status": "ok"})


@bp.route("/account")
@login_required
def account():
    datasets = Dataset.query.filter_by(user_id=current_user.id).order_by(Dataset.created_at.desc()).all()
    return render_template("account.html", datasets=datasets)
